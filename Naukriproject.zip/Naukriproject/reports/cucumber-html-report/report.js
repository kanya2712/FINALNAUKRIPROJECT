$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("testcase.feature");
formatter.feature({
  "line": 1,
  "name": "Naukri Website",
  "description": "",
  "id": "naukri-website",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "To check whether user can register naukri account",
  "description": "",
  "id": "naukri-website;to-check-whether-user-can-register-naukri-account",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@tc01_Register"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "user launchs the chrome browser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user opens the naukri homepage",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "enter valid details for register",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "submit the register button",
  "keyword": "Then "
});
formatter.match({
  "location": "RegisterStep.user_launchs_the_chrome_browser()"
});
formatter.result({
  "duration": 32571233900,
  "status": "passed"
});
formatter.match({
  "location": "RegisterStep.user_opens_the_naukri_homepage()"
});
formatter.result({
  "duration": 1199859100,
  "error_message": "org.openqa.selenium.NoSuchElementException: Cannot locate an element using xpath\u003d//*[@id\u003d\"top-section-widgets.register-upload-cv-wdgt\"]/div[1]/div[2]/div/div[1]/button\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-CUO15N2\u0027, ip: \u0027192.168.0.9\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_211\u0027\nDriver info: driver.version: RemoteWebDriver\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:327)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy32.click(Unknown Source)\r\n\tat com.pages.RegisterPage.clickToRegister(RegisterPage.java:44)\r\n\tat com.stepdefinition.RegisterStep.user_opens_the_naukri_homepage(RegisterStep.java:34)\r\n\tat ✽.When user opens the naukri homepage(testcase.feature:7)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "RegisterStep.enter_valid_details_for_register()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "RegisterStep.submit_the_register_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenarioOutline({
  "line": 13,
  "name": "To check whether user can login naukri account",
  "description": "",
  "id": "naukri-website;to-check-whether-user-can-login-naukri-account",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 12,
      "name": "@tc02_login"
    }
  ]
});
formatter.step({
  "line": 15,
  "name": "user already launchs the chrome",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user already opens naukri homepage",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "user enter \"\u003cEmail Id\u003e\" and \"\u003cpassword\u003e\" to open login page",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "submit the login button",
  "keyword": "And "
});
formatter.examples({
  "line": 20,
  "name": "",
  "description": "",
  "id": "naukri-website;to-check-whether-user-can-login-naukri-account;",
  "rows": [
    {
      "cells": [
        "Email Id",
        "password"
      ],
      "line": 21,
      "id": "naukri-website;to-check-whether-user-can-login-naukri-account;;1"
    },
    {
      "cells": [
        "demo.skp1234@gmail.com",
        "demo@123"
      ],
      "line": 22,
      "id": "naukri-website;to-check-whether-user-can-login-naukri-account;;2"
    },
    {
      "cells": [
        "manasaanthireddy73@gmail.com",
        "Manasa@73"
      ],
      "line": 23,
      "id": "naukri-website;to-check-whether-user-can-login-naukri-account;;3"
    },
    {
      "cells": [
        "demo.skp123#gmail.com",
        "demo123"
      ],
      "line": 24,
      "id": "naukri-website;to-check-whether-user-can-login-naukri-account;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 22,
  "name": "To check whether user can login naukri account",
  "description": "",
  "id": "naukri-website;to-check-whether-user-can-login-naukri-account;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 12,
      "name": "@tc02_login"
    }
  ]
});
formatter.step({
  "line": 15,
  "name": "user already launchs the chrome",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user already opens naukri homepage",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "user enter \"demo.skp1234@gmail.com\" and \"demo@123\" to open login page",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "submit the login button",
  "keyword": "And "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 23,
  "name": "To check whether user can login naukri account",
  "description": "",
  "id": "naukri-website;to-check-whether-user-can-login-naukri-account;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 12,
      "name": "@tc02_login"
    }
  ]
});
formatter.step({
  "line": 15,
  "name": "user already launchs the chrome",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user already opens naukri homepage",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "user enter \"manasaanthireddy73@gmail.com\" and \"Manasa@73\" to open login page",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "submit the login button",
  "keyword": "And "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 24,
  "name": "To check whether user can login naukri account",
  "description": "",
  "id": "naukri-website;to-check-whether-user-can-login-naukri-account;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 12,
      "name": "@tc02_login"
    }
  ]
});
formatter.step({
  "line": 15,
  "name": "user already launchs the chrome",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user already opens naukri homepage",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "user enter \"demo.skp123#gmail.com\" and \"demo123\" to open login page",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "submit the login button",
  "keyword": "And "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 27,
  "name": "To check whether user can go to job search page",
  "description": "",
  "id": "naukri-website;to-check-whether-user-can-go-to-job-search-page",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 26,
      "name": "@tc03_Advancejobsearchpage"
    }
  ]
});
formatter.step({
  "line": 29,
  "name": "user already on chrome",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "user go to naukri homepage",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "user go to search page and search for the jobs",
  "keyword": "Then "
});
formatter.match({
  "location": "AdvanceJobSearchStep.user_already_on_chrome()"
});
formatter.result({
  "duration": 49993971000,
  "status": "passed"
});
formatter.match({
  "location": "AdvanceJobSearchStep.user_go_to_naukri_homepage()"
});
formatter.result({
  "duration": 963300,
  "status": "passed"
});
formatter.match({
  "location": "AdvanceJobSearchStep.user_go_to_search_page_and_search_for_the_jobs()"
});
formatter.result({
  "duration": 31558275300,
  "error_message": "org.openqa.selenium.ElementClickInterceptedException: element click intercepted: Element \u003cdiv class\u003d\"DDinputWrap\"\u003e...\u003c/div\u003e is not clickable at point (673, 292). Other element would receive the click: \u003cdiv tabindex\u003d\"-1\" class\u003d\"Sbtn\" title\u003d\"\" style\u003d\"width:100%\"\u003e...\u003c/div\u003e\n  (Session info: chrome\u003d80.0.3987.163)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-CUO15N2\u0027, ip: \u0027192.168.0.9\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_211\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 80.0.3987.163, chrome: {chromedriverVersion: 80.0.3987.106 (f68069574609..., userDataDir: C:\\Users\\COMPUTER\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:56205}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: 2ad8854a1db5f864591fec24474f678b\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy32.click(Unknown Source)\r\n\tat com.pages.AdvanceJobSearchPage.clickJobSearch(AdvanceJobSearchPage.java:81)\r\n\tat com.stepdefinition.AdvanceJobSearchStep.user_go_to_search_page_and_search_for_the_jobs(AdvanceJobSearchStep.java:38)\r\n\tat ✽.Then user go to search page and search for the jobs(testcase.feature:31)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 34,
  "name": "To check whether user Search Interview questions",
  "description": "",
  "id": "naukri-website;to-check-whether-user-search-interview-questions",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 33,
      "name": "@tc04_InterviewQuestions"
    }
  ]
});
formatter.step({
  "line": 36,
  "name": "user is on chrome",
  "keyword": "Given "
});
formatter.step({
  "line": 37,
  "name": "User opens Naukri homepage",
  "keyword": "When "
});
formatter.step({
  "line": 38,
  "name": "user enter into companies",
  "keyword": "Then "
});
formatter.match({
  "location": "CompaniesStep.user_is_on_chrome()"
});
formatter.result({
  "duration": 39985265600,
  "error_message": "org.openqa.selenium.WebDriverException: unknown error: Chrome failed to start: exited normally.\n  (chrome not reachable)\n  (The process started from chrome location C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe is no longer running, so ChromeDriver is assuming that Chrome has crashed.)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-CUO15N2\u0027, ip: \u0027192.168.0.9\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_211\u0027\nDriver info: driver.version: ChromeDriver\nremote stacktrace: Backtrace:\n\tOrdinal0 [0x007B0C83+1707139]\n\tOrdinal0 [0x007168F1+1075441]\n\tOrdinal0 [0x0068DFC9+516041]\n\tOrdinal0 [0x0061D373+54131]\n\tOrdinal0 [0x0063BFD7+180183]\n\tOrdinal0 [0x0063BDDD+179677]\n\tOrdinal0 [0x00639D4B+171339]\n\tOrdinal0 [0x00621D4A+73034]\n\tOrdinal0 [0x00622DC0+77248]\n\tOrdinal0 [0x00622D59+77145]\n\tOrdinal0 [0x0072BB67+1162087]\n\tGetHandleVerifier [0x0084A966+508998]\n\tGetHandleVerifier [0x0084A6A4+508292]\n\tGetHandleVerifier [0x0085F7B7+594583]\n\tGetHandleVerifier [0x0084B1D6+511158]\n\tOrdinal0 [0x0072402C+1130540]\n\tOrdinal0 [0x0072D4CB+1168587]\n\tOrdinal0 [0x0072D633+1168947]\n\tOrdinal0 [0x00745B35+1268533]\n\tBaseThreadInitThunk [0x772C6359+25]\n\tRtlGetAppContainerNamedObjectPath [0x77777B74+228]\n\tRtlGetAppContainerNamedObjectPath [0x77777B44+180]\n\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.W3CHandshakeResponse.lambda$errorHandler$0(W3CHandshakeResponse.java:62)\r\n\tat org.openqa.selenium.remote.HandshakeResponse.lambda$getResponseFunction$0(HandshakeResponse.java:30)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.lambda$createSession$0(ProtocolHandshake.java:126)\r\n\tat java.util.stream.ReferencePipeline$3$1.accept(Unknown Source)\r\n\tat java.util.Spliterators$ArraySpliterator.tryAdvance(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.forEachWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyIntoWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyInto(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.wrapAndCopyInto(Unknown Source)\r\n\tat java.util.stream.FindOps$FindOp.evaluateSequential(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.evaluate(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.findFirst(Unknown Source)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:128)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:74)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:136)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:213)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:131)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:181)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:168)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:123)\r\n\tat com.BaseClass.LibraryClass.launchApp(LibraryClass.java:30)\r\n\tat com.stepdefinition.CompaniesStep.user_is_on_chrome(CompaniesStep.java:23)\r\n\tat ✽.Given user is on chrome(testcase.feature:36)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "CompaniesStep.user_opens_Naukri_homepage()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "CompaniesStep.user_enter_into_companies()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 41,
  "name": "To check whether user can open Homecalculator page",
  "description": "",
  "id": "naukri-website;to-check-whether-user-can-open-homecalculator-page",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 40,
      "name": "@tc05_HomeCalculator"
    }
  ]
});
formatter.step({
  "line": 43,
  "name": "user launchs the chrome",
  "keyword": "Given "
});
formatter.step({
  "line": 44,
  "name": "user enters naukri homepage",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "user enters home calculator page",
  "keyword": "Then "
});
formatter.match({
  "location": "HomeCalculatorStep.user_launchs_the_chrome()"
});
formatter.result({
  "duration": 16985212900,
  "error_message": "org.openqa.selenium.SessionNotCreatedException: session not created\nfrom chrome not reachable\n  (Session info: chrome\u003d80.0.3987.163)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-CUO15N2\u0027, ip: \u0027192.168.0.9\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_211\u0027\nDriver info: driver.version: ChromeDriver\nremote stacktrace: Backtrace:\n\tOrdinal0 [0x007B0C83+1707139]\n\tOrdinal0 [0x007168F1+1075441]\n\tOrdinal0 [0x0068DE72+515698]\n\tOrdinal0 [0x00687CA8+490664]\n\tOrdinal0 [0x0068839B+492443]\n\tOrdinal0 [0x006892F5+496373]\n\tOrdinal0 [0x00684F05+478981]\n\tOrdinal0 [0x0068ECA0+519328]\n\tOrdinal0 [0x0063CA67+182887]\n\tOrdinal0 [0x0063BDDD+179677]\n\tOrdinal0 [0x00639D4B+171339]\n\tOrdinal0 [0x00621D4A+73034]\n\tOrdinal0 [0x00622DC0+77248]\n\tOrdinal0 [0x00622D59+77145]\n\tOrdinal0 [0x0072BB67+1162087]\n\tGetHandleVerifier [0x0084A966+508998]\n\tGetHandleVerifier [0x0084A6A4+508292]\n\tGetHandleVerifier [0x0085F7B7+594583]\n\tGetHandleVerifier [0x0084B1D6+511158]\n\tOrdinal0 [0x0072402C+1130540]\n\tOrdinal0 [0x0072D4CB+1168587]\n\tOrdinal0 [0x0072D633+1168947]\n\tOrdinal0 [0x00745B35+1268533]\n\tBaseThreadInitThunk [0x772C6359+25]\n\tRtlGetAppContainerNamedObjectPath [0x77777B74+228]\n\tRtlGetAppContainerNamedObjectPath [0x77777B44+180]\n\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.W3CHandshakeResponse.lambda$errorHandler$0(W3CHandshakeResponse.java:62)\r\n\tat org.openqa.selenium.remote.HandshakeResponse.lambda$getResponseFunction$0(HandshakeResponse.java:30)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.lambda$createSession$0(ProtocolHandshake.java:126)\r\n\tat java.util.stream.ReferencePipeline$3$1.accept(Unknown Source)\r\n\tat java.util.Spliterators$ArraySpliterator.tryAdvance(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.forEachWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyIntoWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyInto(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.wrapAndCopyInto(Unknown Source)\r\n\tat java.util.stream.FindOps$FindOp.evaluateSequential(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.evaluate(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.findFirst(Unknown Source)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:128)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:74)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:136)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:213)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:131)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:181)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:168)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:123)\r\n\tat com.BaseClass.LibraryClass.launchApp(LibraryClass.java:30)\r\n\tat com.stepdefinition.HomeCalculatorStep.user_launchs_the_chrome(HomeCalculatorStep.java:23)\r\n\tat ✽.Given user launchs the chrome(testcase.feature:43)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "HomeCalculatorStep.user_enters_naukri_homepage()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "HomeCalculatorStep.user_enters_home_calculator_page()"
});
formatter.result({
  "status": "skipped"
});
});