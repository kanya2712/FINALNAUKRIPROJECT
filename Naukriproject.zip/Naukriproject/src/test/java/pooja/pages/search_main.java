package pooja.pages;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class search_main {
	static WebDriver driver;

	public void launchChrome(String browser)
	{
		//To launch chrome browser
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		//To launch firefox browser
				else if(browser.equalsIgnoreCase("firefox"))
				{
					System.setProperty("webdriver.geckodriver.driver","C:\\geckodriver-v0.26.0-win64\\geckodriver.exe");
					driver = new FirefoxDriver();
				}
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	//To launch naukri url
	public void url()
	{
		driver.get("https://www.naukri.com");
		String windowTitle= getCurrentWindowTitle();
		String mainWindow = getMainWindowHandle(driver);
		Assert.assertTrue(closeAllOtherWindows(mainWindow));
		Assert.assertTrue(windowTitle.contains("Jobs - Recruitment"));
	}

	public String getMainWindowHandle(WebDriver driver) {
		return driver.getWindowHandle();
	}

	public String getCurrentWindowTitle() {
		String windowTitle = driver.getTitle();
		return windowTitle;
	}

	//To close all the other windows except the main window.
	public static boolean closeAllOtherWindows(String openWindowHandle) {
		Set<String> allWindowHandles = driver.getWindowHandles();
		for (String currentWindowHandle : allWindowHandles) {
			if (!currentWindowHandle.equals(openWindowHandle)) {
				driver.switchTo().window(currentWindowHandle);
				driver.close();
			}
		}

		driver.switchTo().window(openWindowHandle);
		if (driver.getWindowHandles().size() == 1)
			return true;
		else
			return false;
	}
	//To login to the naukri application
	public void login() throws IOException
	{   
		driver.findElement(By.xpath("//*[@id=\"login_Layer\"]/div")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/form/div[2]/input")).sendKeys("demo.skp1234@gmail.com");
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/form/div[3]/input")).sendKeys("demo@123");
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/form/div[5]/button")).click();
	}
	//To search for a job 
	public void search_job() throws InterruptedException {

		driver.findElement(By.xpath("//input[@id='qsb-keyskill-sugg']")).sendKeys("cognizant");
		driver.findElement(By.xpath("//input[@id='qsb-location-sugg']")).sendKeys("chennai");
		driver.findElement(By.xpath("//*[@id=\"search-jobs\"]/button")).click();
		Thread.sleep(3000);
		driver.close();

	}
}

