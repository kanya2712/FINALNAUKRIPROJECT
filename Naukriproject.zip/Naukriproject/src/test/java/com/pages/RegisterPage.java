package com.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class RegisterPage {
	
	WebDriver driver;
//command for clicks on free register 
	@FindBy(xpath = "//*[@id=\"top-section-widgets.register-upload-cv-wdgt\"]/div[1]/div[2]/div/div[1]/button")
	WebElement Registerfree;
//command for click on fresher
	@FindBy(xpath = "//*[@id=\"document-section-widgets.register-wdgt\"]/div/div[2]/form/div[3]/div[2]/button")
	WebElement fresher;
//command for going to new registration
	@FindBy(id = "fname")
	WebElement name;
// command for going to email id feild
	@FindBy(id = "email")
	WebElement email;
//command for entering password
	@FindBy(name = "password")
	WebElement password;
// displayed as already registered
	@FindBy(id = "typePassword")
	WebElement alreadyreg;
//clicks on submitbutton
	@FindBy(xpath = "//*[@id=\"emailExistBox\"]/div/div[2]/form/div[2]/button")
	WebElement submit;
	// Constructor
	public RegisterPage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
	}

	// Opens the Register page
	public void clickToRegister() throws InterruptedException {
		
		Registerfree.click();
		fresher.click();
		Thread.sleep(2000);

	}

	// Enters Username
	public void enterName(String un) {
		
		name.sendKeys(un);

	}

	// Enters Email Id
	public void enterEmail(String em) {
		
		email.sendKeys(em);

	}

	// Enters Password
	public void enterPassword(String pass) throws InterruptedException {
		
		password.sendKeys(pass);

	}

	// Again enters Password
	public void enterKey(String p) throws InterruptedException {
		
		alreadyreg.sendKeys(p);
		Thread.sleep(1000);
	}

	// Submits the Register button
	public void clickSubmit() {
		//clicks on submit button
		submit.click();

	}

}
